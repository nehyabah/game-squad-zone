-- AlterTable
ALTER TABLE "SquadMember" ADD COLUMN "lastReadAt" DATETIME;
